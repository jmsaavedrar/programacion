"""
"""
import numpy as np

def mergesort_recursivo(A, i, j):
    """
    A: es una lista
    i: pos inicial de A
    j: pos final de A
    """
    if i<j : # condicion de parada
        k = (i + j) // 2 # calcular centro
        mergesort_recursivo(A, i, k)
        mergesort_recursivo(A, k+1, j)
        merge(A, i, k, j)


def merge(lista, i, k, j):
    """
    i: inicio
    k: punto de división
    j: fin
    lista izquierda va de i a k
    lista derecha va de (k + 1) a j
    """
    lista_ordenada = []
    p1 = i # inicio de lista izq
    p2 = k+1 # inicio de lista der
    while p1 <= k and p2 <= j :
        if lista[p1] < lista[p2] :
            lista_ordenada.append(lista[p1])
            p1 += 1
        else :
            lista_ordenada.append(lista[p2])
            p2 += 1
            
    while p1 <= k :
        lista_ordenada.append(lista[p1])
        p1 += 1
        
    while p2 <= j :
        lista_ordenada.append(lista[p2])
        p2 += 1
                
    lista[i:j+1]=lista_ordenada

#Ejemplo de uso de mergesort
A =[]
for i in range(10) :
    A.append(np.random.randint(0,100))

print(A)    
mergesort_recursivo(A, 0, len(A)-1)
print('ordenado')
print(A)



