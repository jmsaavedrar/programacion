"""
"""

def fact(n):
    if n==1 or n == 0 :
        return 1
    else :
        return n*fact(n-1)

def fib(n):
    if n == 1 or n == 0 :
        return n
    else :
        return fib(n-1) + fib(n-2)

#Ejemplo de factorial
# for i in range(10) :
#     print('{}! = {}'.format(i, fact(i)))

#Ejemplo de fibonacci
for i in range(20) :
    print('{} = {}'.format(i, fib(i)))
