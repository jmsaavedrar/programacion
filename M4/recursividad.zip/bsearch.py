"""
return position if the val exists or -1 if not
"""

A = [1,3,12,14,23,34,55,65,75,78]


def b_search(A, valor, i, j):
    if i<=j :
        k = (i+j) // 2
        if valor==A[k] :
            return k
        elif valor < A[k] :
            return b_search(A, valor, i,k-1)
        else :
            return b_search(A, valor, k+1,j)
    else :
        return -1
        
    
#Ejemplo de uso
valor = 34
pos = b_search(A, valor, 0, len(A)-1)
print('{} en pos {}'.format(valor, pos))
        